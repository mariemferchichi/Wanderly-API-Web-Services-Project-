-- Create Database
CREATE DATABASE WebServiceProject;

-- Use the database
\c WebServiceProject;

-- Create Tables

-- Table: users
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(200) NOT NULL,
    role VARCHAR(50) NOT NULL
);

-- Table: accommodations
CREATE TABLE accommodations (
    accommodation_id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    address VARCHAR(300) NOT NULL,
    city VARCHAR(100) NOT NULL,
    type VARCHAR(80) NOT NULL,
    price_range VARCHAR(100) NOT NULL,
    rating FLOAT
);

-- Table: tourist_attractions
CREATE TABLE tourist_attractions (
    attraction_id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description VARCHAR(500) NOT NULL,
    location VARCHAR(300) NOT NULL,
    city VARCHAR(100) NOT NULL,
    type VARCHAR(80) NOT NULL,
    rating FLOAT
);

-- Table: cuisines
CREATE TABLE cuisines (
    restaurant_id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    cuisine_type VARCHAR(80) NOT NULL,
    location VARCHAR(300) NOT NULL,
    rating FLOAT
);

-- Table: cultural_experiences
CREATE TABLE cultural_experiences (
    experience_id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description VARCHAR(500) NOT NULL,
    date TIMESTAMP NOT NULL,
    location VARCHAR(300) NOT NULL,
    type VARCHAR(80) NOT NULL
);

-- Table: events
CREATE TABLE events (
    event_id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description VARCHAR(500) NOT NULL,
    date TIMESTAMP NOT NULL,
    city VARCHAR(100) NOT NULL,
    type VARCHAR(80) NOT NULL
);

-- Table: local_services
CREATE TABLE local_services (
    service_id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    type VARCHAR(80) NOT NULL,
    contact_details VARCHAR(300) NOT NULL
);

-- Table: transportation
CREATE TABLE transportation (
    transport_id SERIAL PRIMARY KEY,
    type VARCHAR(80) NOT NULL,
    details VARCHAR(300) NOT NULL
);

