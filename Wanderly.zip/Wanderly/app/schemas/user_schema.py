from marshmallow import Schema, fields, validate

class UserSchema(Schema):
    user_id = fields.Int(dump_only=True)  # Primary Key, not required when creating
    name = fields.Str(required=True, validate=validate.Length(min=1, max=100))  # User's name, required
    email = fields.Email(required=True)  # Email, required and validated
    password = fields.Str(load_only=True, required=True, validate=validate.Length(min=6))  # Password, write-only
    role = fields.Str(required=True, validate=validate.OneOf(["Admin", "User"]))  # Role, must be either Admin or User
