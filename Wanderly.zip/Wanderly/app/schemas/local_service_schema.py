from marshmallow import Schema, fields, validate

class LocalServiceSchema(Schema):
    service_id = fields.Int(dump_only=True)  # Primary Key, auto-generated
    name = fields.Str(required=True, validate=validate.Length(min=1, max=200))  # Service name (e.g., "Hospital", "Embassy")
    type = fields.Str(required=True, validate=validate.OneOf(["emergency", "hospital", "embassy", "police"]))  # Service type
    contact_details = fields.Str(required=True, validate=validate.Length(min=1, max=300))  # Contact details (phone, email, etc.)
