from marshmallow import Schema, fields, validate

class CuisineSchema(Schema):
    restaurant_id = fields.Int(dump_only=True)  # Primary Key, auto-generated
    name = fields.Str(required=True, validate=validate.Length(min=1, max=200))  # Restaurant name
    cuisine_type = fields.Str(required=True, validate=validate.OneOf(["Tunisian", "Mediterranean", "Italian", "French", "Asian"]))  # Cuisine type
    location = fields.Str(required=True, validate=validate.Length(min=1, max=300))  # Location of the restaurant
    rating = fields.Float(required=False, validate=validate.Range(min=0, max=5))  # Rating of the restaurant (optional)
