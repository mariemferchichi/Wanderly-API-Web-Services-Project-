from marshmallow import Schema, fields

class AttractionSchema(Schema):
    attraction_id = fields.Int(dump_only=True)
    name = fields.Str(required=True)
    description = fields.Str(required=True)
    location = fields.Str(required=True)
    city = fields.Str(required=True)
    type = fields.Str(required=True)
    rating = fields.Float()
