from marshmallow import Schema, fields, validate

class AccommodationSchema(Schema):
    accommodation_id = fields.Int(dump_only=True)  # Primary Key, auto-generated
    name = fields.Str(required=True, validate=validate.Length(min=1, max=200))  # Accommodation name
    address = fields.Str(required=True, validate=validate.Length(min=1, max=300))  # Full address
    city = fields.Str(required=True, validate=validate.Length(min=1, max=100))  # City name
    type = fields.Str(required=True, validate=validate.OneOf(["hotel", "guesthouse", "hostel", "resort"]))  # Type of accommodation
    price_range = fields.Str(required=True, validate=validate.Length(min=1, max=50))  # Price range (e.g., "$$", "Luxury")
    rating = fields.Float(required=False, validate=validate.Range(min=0, max=5))  # Rating (0-5, optional)
