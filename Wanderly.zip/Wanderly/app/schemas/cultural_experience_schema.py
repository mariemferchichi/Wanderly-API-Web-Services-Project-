from marshmallow import Schema, fields

class CulturalExperienceSchema(Schema):
    experience_id = fields.Int(dump_only=True)  # Primary Key, not required when creating
    name = fields.Str(required=True)  # Name of the cultural experience, required
    description = fields.Str(required=True)  # Detailed description of the experience, required
    date = fields.Date(required=True)  # Date of the experience, required
    location = fields.Str(required=True)  # Location where the experience is held, required
    type = fields.Str(required=True)  # Type of experience (e.g., music, art, tradition), required
