from marshmallow import Schema, fields, validate

class EventSchema(Schema):
    event_id = fields.Int(dump_only=True)  # Primary Key, auto-generated
    name = fields.Str(required=True, validate=validate.Length(min=1, max=200))  # Event name
    description = fields.Str(required=True, validate=validate.Length(min=1, max=500))  # Event description
    date = fields.Date(required=True)  # Event date
    city = fields.Str(required=True, validate=validate.Length(min=1, max=100))  # City where the event takes place
    type = fields.Str(required=True, validate=validate.OneOf(["concert", "exhibition", "festival", "workshop"]))  # Event type
