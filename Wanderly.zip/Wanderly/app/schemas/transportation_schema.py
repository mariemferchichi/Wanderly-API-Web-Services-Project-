from marshmallow import Schema, fields, validate

class TransportationSchema(Schema):
    transport_id = fields.Int(dump_only=True)  # Primary Key, auto-generated
    type = fields.Str(required=True, validate=validate.OneOf(["public transport", "rental car", "taxi", "shuttle"]))  # Type of transport
    details = fields.Str(required=True, validate=validate.Length(min=1, max=300))  # Details about the transport option
