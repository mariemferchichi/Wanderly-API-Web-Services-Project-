from flask_sqlalchemy import SQLAlchemy

# Initialize the db object
db = SQLAlchemy()
