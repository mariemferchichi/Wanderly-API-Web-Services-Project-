from flask import Flask
from flask_smorest import Api
from app.db import db

# Import models 
from app import models

# Import blueprints for each resource (to be created)
from app.routes.attraction_routes import attraction_bp
from app.routes.cultural_experience_routes import cultural_experience_bp
from app.routes.accommodation_routes import accommodation_bp
from app.routes.event_routes import event_bp
from app.routes.cuisine_routes import cuisine_bp
from app.routes.service_routes import service_bp
from app.routes.transportation_routes import transportation_bp
from flask_jwt_extended import JWTManager
from app.routes.user import user_bp  # Correct import of auth_routes

def create_app(db_url=None):
    app = Flask(__name__)
    
    # Configure the application
    app.config["API_TITLE"] = "Wanderly Discover Tunisia API"
    app.config["API_VERSION"] = "v1"
    app.config["OPENAPI_VERSION"] = "3.0.3"
    app.config["OPENAPI_URL_PREFIX"] = "/"
    app.config["OPENAPI_SWAGGER_UI_PATH"] = "/swagger-ui"
    app.config["OPENAPI_SWAGGER_UI_URL"] = "https://cdn.jsdelivr.net/npm/swagger-ui-dist/"
    app.config["SQLALCHEMY_DATABASE_URI"] = db_url or "sqlite:///data.db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["PROPAGATE_EXCEPTIONS"] = True
    
    # Initialize database
    db.init_app(app)
    
    # Initialize the API with Flask-Smorest
    api = Api(app)


    # Create the database tables if they don't exist yet
    with app.app_context():
        db.create_all()

    # Register blueprints for different resources (models)
    api.register_blueprint(user_bp, url_prefix='/api/auth')  # Register auth_routes blueprint with a prefix
    api.register_blueprint(attraction_bp)
    api.register_blueprint(cultural_experience_bp)
    api.register_blueprint(accommodation_bp)
    api.register_blueprint(event_bp)
    api.register_blueprint(cuisine_bp)
    api.register_blueprint(service_bp)
    api.register_blueprint(transportation_bp)  # Register transportation blueprint

    return app
