from app.db import db

class UserModel(db.Model):
    __tablename__ = "users"

    # Primary Key
    user_id = db.Column(db.Integer, primary_key=True)

    # Fields
    name = db.Column(db.String(100), unique=False, nullable=False)  # Name of the user
    email = db.Column(db.String(100), unique=True, nullable=False)  # Email of the user
    password = db.Column(db.String(200), unique=False, nullable=False)  # Hashed password for security
    role = db.Column(db.String(50), nullable=False)  # Role (e.g., Admin/User)


    def __init__(self, name, email, password, role):
        self.name = name
        self.email = email
        self.password = password
        self.role = role

    def __repr__(self):
        return f"<User(name={self.name}, email={self.email}, role={self.role})>"

    # Optional: Method to verify user credentials or role
    @classmethod
    def find_by_email(cls, email):
        return cls.query.filter_by(email=email).first()

    @classmethod
    def find_by_id(cls, user_id):
        return cls.query.filter_by(user_id=user_id).first()
