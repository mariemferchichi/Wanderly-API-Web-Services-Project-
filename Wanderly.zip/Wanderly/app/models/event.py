from app.db import db

class EventModel(db.Model):
    __tablename__ = "events"

    # Primary Key
    event_id = db.Column(db.Integer, primary_key=True)

    # Fields
    name = db.Column(db.String(200), unique=False, nullable=False)  # Event name
    description = db.Column(db.String(500), unique=False, nullable=False)  # Event description
    date = db.Column(db.DateTime, nullable=False)  # Event date
    city = db.Column(db.String(100), unique=False, nullable=False)  # Event city
    type = db.Column(db.String(80), unique=False, nullable=False)  # Event type (e.g., concert, exhibition)

    def __init__(self, name, description, date, city, type):
        self.name = name
        self.description = description
        self.date = date
        self.city = city
        self.type = type

    def __repr__(self):
        return f"<Event(name={self.name}, type={self.type})>"
