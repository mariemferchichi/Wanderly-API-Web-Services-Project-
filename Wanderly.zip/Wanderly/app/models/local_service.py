from app.db import db

class LocalServiceModel(db.Model):
    __tablename__ = "local_services"

    # Primary Key
    service_id = db.Column(db.Integer, primary_key=True)

    # Fields
    name = db.Column(db.String(200), unique=False, nullable=False)  # Service name
    type = db.Column(db.String(80), unique=False, nullable=False)  # Service type (e.g., emergency, hospital, embassy)
    contact_details = db.Column(db.String(300), unique=False, nullable=False)  # Contact details

    def __init__(self, name, type, contact_details):
        self.name = name
        self.type = type
        self.contact_details = contact_details

    def __repr__(self):
        return f"<LocalService(name={self.name}, type={self.type})>"
