from app.db import db

class TransportationModel(db.Model):
    __tablename__ = "transportation"

    # Primary Key
    transport_id = db.Column(db.Integer, primary_key=True)

    # Fields
    type = db.Column(db.String(80), unique=False, nullable=False)  # Type of transportation (e.g., public transport, rental car)
    details = db.Column(db.String(300), unique=False, nullable=False)  # Details (e.g., bus route, car rental details)

    def __init__(self, type, details):
        self.type = type
        self.details = details

    def __repr__(self):
        return f"<Transportation(type={self.type})>"
