from app.db import db

class CuisineModel(db.Model):
    __tablename__ = "cuisines"

    # Primary Key
    restaurant_id = db.Column(db.Integer, primary_key=True)

    # Fields
    name = db.Column(db.String(200), unique=False, nullable=False)  # Restaurant name
    cuisine_type = db.Column(db.String(80), unique=False, nullable=False)  # Cuisine type (e.g., Tunisian, Mediterranean)
    location = db.Column(db.String(300), unique=False, nullable=False)  # Location
    rating = db.Column(db.Float, nullable=True)  # Rating (optional)

    def __init__(self, name, cuisine_type, location, rating=None):
        self.name = name
        self.cuisine_type = cuisine_type
        self.location = location
        self.rating = rating

    def __repr__(self):
        return f"<Cuisine(name={self.name}, cuisine_type={self.cuisine_type})>"
