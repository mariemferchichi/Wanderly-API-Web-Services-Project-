from app.db import db

class AttractionModel(db.Model):
    __tablename__ = "tourist_attractions"

    # Primary Key
    attraction_id = db.Column(db.Integer, primary_key=True)

    # Fields
    name = db.Column(db.String(200), unique=False, nullable=False)  # Name of the attraction
    description = db.Column(db.String(500), unique=False, nullable=False)  # Description of the attraction
    location = db.Column(db.String(300), unique=False, nullable=False)  # Location of the attraction
    city = db.Column(db.String(100), unique=False, nullable=False)  # City where the attraction is located
    type = db.Column(db.String(80), unique=False, nullable=False)  # Type (museum, park, beach, etc.)
    rating = db.Column(db.Float, nullable=True)  # Rating (Optional, can be null)


    def __init__(self, name, description, location, city, type, rating=None):
        self.name = name
        self.description = description
        self.location = location
        self.city = city
        self.type = type
        self.rating = rating

    def __repr__(self):
        return f"<Attraction(name={self.name}, city={self.city})>"
