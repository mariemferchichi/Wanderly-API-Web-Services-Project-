from app.db import db

class AccommodationModel(db.Model):
    __tablename__ = "accommodations"

    # Primary Key
    accommodation_id = db.Column(db.Integer, primary_key=True)

    # Fields
    name = db.Column(db.String(200), unique=False, nullable=False)  # Name of the accommodation
    address = db.Column(db.String(300), unique=False, nullable=False)  # Address of the accommodation
    city = db.Column(db.String(100), unique=False, nullable=False)  # City where the accommodation is located
    type = db.Column(db.String(80), unique=False, nullable=False)  # Type (e.g., hotel, guesthouse)
    price_range = db.Column(db.String(100), unique=False, nullable=False)  # Price range (e.g., "100TND - 200TND")
    rating = db.Column(db.Float, nullable=True)  # Rating (Optional)

    def __init__(self, name, address, city, type, price_range, rating=None):
        self.name = name
        self.address = address
        self.city = city
        self.type = type
        self.price_range = price_range
        self.rating = rating

    def __repr__(self):
        return f"<Accommodation(name={self.name}, city={self.city}, type={self.type})>"
