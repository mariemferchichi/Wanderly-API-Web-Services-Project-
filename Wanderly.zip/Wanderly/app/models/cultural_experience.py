from app.db import db

class CulturalExperienceModel(db.Model):
    __tablename__ = "cultural_experiences"

    # Primary Key
    experience_id = db.Column(db.Integer, primary_key=True)

    # Fields
    name = db.Column(db.String(200), unique=False, nullable=False)  # Name of the cultural experience
    description = db.Column(db.String(500), unique=False, nullable=False)  # Description of the experience
    date = db.Column(db.DateTime, nullable=False)  # Date of the experience
    location = db.Column(db.String(300), unique=False, nullable=False)  # Location of the experience
    type = db.Column(db.String(80), unique=False, nullable=False)  # Type of experience (e.g., music, art, tradition)

    def __init__(self, name, description, date, location, type):
        self.name = name
        self.description = description
        self.date = date
        self.location = location
        self.type = type

    def __repr__(self):
        return f"<CulturalExperience(name={self.name}, date={self.date}, type={self.type})>"
