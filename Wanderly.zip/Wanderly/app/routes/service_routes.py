from flask import request, jsonify
from flask_smorest import Blueprint
from flask_login import login_required, current_user
from app.models import LocalServiceModel
from app import db
from app.schemas import LocalServiceSchema
from sqlalchemy.exc import SQLAlchemyError

service_bp = Blueprint("Local Services", __name__)

# Only admin can create services
@service_bp.route('/services', methods=['POST'])
@login_required
def create_service():
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can create services
    try:
        data = request.get_json()
        service = LocalServiceModel(**data)
        db.session.add(service)
        db.session.commit()
        return LocalServiceSchema().jsonify(service), 201  # Created status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get all services - accessible to all users
@service_bp.route('/services', methods=['GET'])
def get_services():
    try:
        services = LocalServiceModel.query.all()
        return LocalServiceSchema(many=True).jsonify(services), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error



# Only admin can update services
@service_bp.route('/services/<int:service_id>', methods=['PUT'])
@login_required
def update_service(service_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can update services
    try:
        service = LocalServiceModel.query.get_or_404(service_id)
        data = request.get_json()
        for key, value in data.items():
            setattr(service, key, value)
        db.session.commit()
        return LocalServiceSchema().jsonify(service), 200  # Success status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Only admin can delete services
@service_bp.route('/services/<int:service_id>', methods=['DELETE'])
@login_required
def delete_service(service_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can delete services
    try:
        service = LocalServiceModel.query.get_or_404(service_id)
        db.session.delete(service)
        db.session.commit()
        return '', 204  # No Content status code (successful deletion)
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get services by type (e.g., hospital, embassy) - accessible to all users
@service_bp.route('/services/type/<string:type>', methods=['GET'])
def get_services_by_type(type):
    try:
        services = LocalServiceModel.query.filter(LocalServiceModel.type.ilike(f'%{type}%')).all()
        if not services:
            return jsonify({"message": "No services found for this type"}), 404  # Not Found status code
        return LocalServiceSchema(many=True).jsonify(services), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get services by city - accessible to all users
@service_bp.route('/services/city/<string:city>', methods=['GET'])
def get_services_by_city(city):
    try:
        services = LocalServiceModel.query.filter(LocalServiceModel.city.ilike(f'%{city}%')).all()
        if not services:
            return jsonify({"message": "No services found for this city"}), 404  # Not Found status code
        return LocalServiceSchema(many=True).jsonify(services), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error
