from flask import request, jsonify
from flask_smorest import Blueprint
from flask_login import login_required, current_user
from app.models import CulturalExperienceModel
from app import db
from app.schemas import CulturalExperienceSchema
from sqlalchemy.exc import SQLAlchemyError

cultural_experience_bp = Blueprint("Cultural Experiences", __name__)

# Only admin can create cultural experiences
@cultural_experience_bp.route('/culture', methods=['POST'])
@login_required
def create_cultural_experience():
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can create cultural experiences
    try:
        data = request.get_json()
        cultural_experience = CulturalExperienceModel(**data)
        db.session.add(cultural_experience)
        db.session.commit()
        return CulturalExperienceSchema().jsonify(cultural_experience), 201  # Created status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get all cultural experiences - accessible to all users
@cultural_experience_bp.route('/culture', methods=['GET'])
def get_cultural_experiences():
    try:
        cultural_experiences = CulturalExperienceModel.query.all()
        return CulturalExperienceSchema(many=True).jsonify(cultural_experiences), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error


# Only admin can update cultural experiences
@cultural_experience_bp.route('/culture/<int:cultural_experience_id>', methods=['PUT'])
@login_required
def update_cultural_experience(cultural_experience_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can update cultural experiences
    try:
        cultural_experience = CulturalExperienceModel.query.get_or_404(cultural_experience_id)
        data = request.get_json()
        for key, value in data.items():
            setattr(cultural_experience, key, value)
        db.session.commit()
        return CulturalExperienceSchema().jsonify(cultural_experience), 200  # Success status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Only admin can delete cultural experiences
@cultural_experience_bp.route('/culture/<int:cultural_experience_id>', methods=['DELETE'])
@login_required
def delete_cultural_experience(cultural_experience_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can delete cultural experiences
    try:
        cultural_experience = CulturalExperienceModel.query.get_or_404(cultural_experience_id)
        db.session.delete(cultural_experience)
        db.session.commit()
        return '', 204  # No Content status code (successful deletion)
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get cultural experience by name - accessible to all users
@cultural_experience_bp.route('/culture/name/<string:name>', methods=['GET'])
def get_cultural_experience_by_name(name):
    try:
        cultural_experience = CulturalExperienceModel.query.filter(CulturalExperienceModel.name.ilike(f'%{name}%')).first()  # Case-insensitive match
        if not cultural_experience:
            return jsonify({"message": "Cultural experience not found"}), 404  # Not Found status code
        return CulturalExperienceSchema().jsonify(cultural_experience), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error
