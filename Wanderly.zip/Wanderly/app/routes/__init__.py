from app.routes.attraction_routes import attraction_bp
from app.routes.cultural_experience_routes import cultural_experience_bp
from app.routes.accommodation_routes import accommodation_bp
from app.routes.event_routes import event_bp
from app.routes.cuisine_routes import cuisine_bp
from app.routes.service_routes import service_bp
from app.routes.user import user_bp

__all__ = [
    "attraction_bp",
    "cultural_experience_bp",
    "accommodation_bp",
    "event_bp",
    "cuisine_bp",
    "service_bp",
    "user_bp"
]
