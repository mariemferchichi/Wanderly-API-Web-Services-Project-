from flask import request, jsonify
from flask_smorest import Blueprint
from flask_login import login_required, current_user
from app.models import AccommodationModel
from app import db
from app.schemas import AccommodationSchema
from sqlalchemy.exc import SQLAlchemyError

accommodation_bp = Blueprint("Accommodations", __name__)

# Only admin can create accommodations
@accommodation_bp.route('/accommodations', methods=['POST'])
@login_required
def create_accommodation():
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can create accommodations
    try:
        data = request.get_json()
        accommodation = AccommodationModel(**data)
        db.session.add(accommodation)
        db.session.commit()
        return AccommodationSchema().jsonify(accommodation), 201  # Created status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get all accommodations - accessible to all users
@accommodation_bp.route('/accommodations', methods=['GET'])
def get_accommodations():
    try:
        accommodations = AccommodationModel.query.all()
        return AccommodationSchema(many=True).jsonify(accommodations), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error


# Only admin can update accommodations
@accommodation_bp.route('/accommodations/<int:accommodation_id>', methods=['PUT'])
@login_required
def update_accommodation(accommodation_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can update accommodations
    try:
        accommodation = AccommodationModel.query.get_or_404(accommodation_id)
        data = request.get_json()
        for key, value in data.items():
            setattr(accommodation, key, value)
        db.session.commit()
        return AccommodationSchema().jsonify(accommodation), 200  # Success status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Only admin can delete accommodations
@accommodation_bp.route('/accommodations/<int:accommodation_id>', methods=['DELETE'])
@login_required
def delete_accommodation(accommodation_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can delete accommodations
    try:
        accommodation = AccommodationModel.query.get_or_404(accommodation_id)
        db.session.delete(accommodation)
        db.session.commit()
        return '', 204  # No Content status code (successful deletion)
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get accommodations by city - accessible to all users
@accommodation_bp.route('/accommodations/city/<string:city>', methods=['GET'])
def get_accommodations_by_city(city):
    try:
        accommodations = AccommodationModel.query.filter(AccommodationModel.city.ilike(f'%{city}%')).all()
        if not accommodations:
            return jsonify({"message": "No accommodations found for this city"}), 404  # Not Found status code
        return AccommodationSchema(many=True).jsonify(accommodations), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get accommodation by name - accessible to all users
@accommodation_bp.route('/accommodations/name/<string:name>', methods=['GET'])
def get_accommodation_by_name(name):
    try:
        accommodation = AccommodationModel.query.filter(AccommodationModel.name.ilike(f'%{name}%')).first()  # Case-insensitive match
        if not accommodation:
            return jsonify({"message": "Accommodation not found"}), 404  # Not Found status code
        return AccommodationSchema().jsonify(accommodation), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error
