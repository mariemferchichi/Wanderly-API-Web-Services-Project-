from flask import Flask, request, jsonify
from flask_smorest import Blueprint
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import timedelta
from app import db
from app import utilities
from app.schemas import UserSchema
from app.models import UserModel

# Initialize JWT Manager
jwt = JWTManager()

# Blueprint for user management routes
user_bp = Blueprint('Users', __name__)

# POST: Register a new user
@user_bp.route('/register', methods=['POST'])
def register_user():
    data = request.get_json()

    if not data.get('name') or not data.get('email') or not data.get('password'):
        return jsonify({"message": "Missing required fields"}), 400

    # Admin role validation
    if data.get('role') == 'admin' and not data['password'].startswith('AD'):
        return jsonify({"message": "You don't have permission to have that role"}), 403

    # Check if email or name already exists
    existing_user = UserModel.query.filter(
        (UserModel.name == data['name']) | (UserModel.email == data['email'])
    ).first()
    if existing_user:
        return jsonify({"message": "Name or email already taken"}), 400

    # Hash the password
    hashed_password = generate_password_hash(data['password'], method='sha256')

    # Create a new user
    new_user = UserModel(
        name=data['name'],
        email=data['email'],
        password=hashed_password,
        role=data.get('role', 'user')  # Default role is 'user'
    )
    try:
        db.session.add(new_user)
        db.session.commit()
        return jsonify({"message": "User registered successfully"}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error: {str(e)}"}), 500

# POST: Login
@user_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()

    if not data.get('name') or not data.get('password'):
        return jsonify({"message": "Missing required fields"}), 400

    # Find user by name
    user = UserModel.query.filter_by(name=data['name']).first()
    if user and check_password_hash(user.password, data['password']):
        access_token = create_access_token(identity=user.id, expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
        return jsonify({"access_token": access_token, "token_type": "bearer"}), 200
    else:
        return jsonify({"message": "Invalid credentials"}), 401

# PUT: Update user parameters (except role)
@user_bp.route('/update', methods=['PUT'])
@jwt_required()
def update_user():
    current_user_id = get_jwt_identity()
    user = UserModel.query.get(current_user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    data = request.get_json()

    if 'role' in data:
        return jsonify({"message": "Role cannot be updated"}), 403

    # Update allowed parameters
    if data.get('name'):
        user.name = data['name']
    if data.get('email'):
        user.email = data['email']
    if data.get('password'):
        user.password = generate_password_hash(data['password'], method='sha256')

    try:
        db.session.commit()
        return jsonify({"message": "User updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error: {str(e)}"}), 500

# DELETE: Delete a user
@user_bp.route('/<int:user_id>', methods=['DELETE'])
@jwt_required()
def delete_user(user_id):
    current_user_id = get_jwt_identity()
    user = UserModel.query.get(current_user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    # Only admins can delete other users
    if user.role != 'admin':
        return jsonify({"message": "You do not have permission to delete users"}), 403

    user_to_delete = UserModel.query.get(user_id)
    if not user_to_delete:
        return jsonify({"message": "User to delete not found"}), 404

    try:
        db.session.delete(user_to_delete)
        db.session.commit()
        return jsonify({"message": "User deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error: {str(e)}"}), 500

# GET: Retrieve all users
@user_bp.route('/', methods=['GET'])
@jwt_required()
def get_all_users():
    current_user_id = get_jwt_identity()
    user = UserModel.query.get(current_user_id)

    if not user or user.role != 'admin':
        return jsonify({"message": "You do not have permission to view this resource"}), 403

    users = UserModel.query.all()
    user_list = [
        {"id": u.id, "name": u.name, "email": u.email, "role": u.role}
        for u in users
    ]
    return jsonify({"users": user_list}), 200
