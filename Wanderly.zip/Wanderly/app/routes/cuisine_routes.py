from flask import request, jsonify
from flask_smorest import Blueprint
from flask_login import login_required, current_user
from app.models import CuisineModel
from app import db
from app.schemas import CuisineSchema
from sqlalchemy.exc import SQLAlchemyError

cuisine_bp = Blueprint("Cuisines", __name__)

# Only admin can create cuisines
@cuisine_bp.route('/cuisines', methods=['POST'])
@login_required
def create_cuisine():
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can create cuisines
    try:
        data = request.get_json()
        cuisine = CuisineModel(**data)
        db.session.add(cuisine)
        db.session.commit()
        return CuisineSchema().jsonify(cuisine), 201  # Created status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get all cuisines - accessible to all users
@cuisine_bp.route('/cuisines', methods=['GET'])
def get_cuisines():
    try:
        cuisines = CuisineModel.query.all()
        return CuisineSchema(many=True).jsonify(cuisines), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error


# Only admin can update cuisines
@cuisine_bp.route('/cuisines/<int:restaurant_id>', methods=['PUT'])
@login_required
def update_cuisine(restaurant_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can update cuisines
    try:
        cuisine = CuisineModel.query.get_or_404(restaurant_id)
        data = request.get_json()
        for key, value in data.items():
            setattr(cuisine, key, value)
        db.session.commit()
        return CuisineSchema().jsonify(cuisine), 200  # Success status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Only admin can delete cuisines
@cuisine_bp.route('/cuisines/<int:restaurant_id>', methods=['DELETE'])
@login_required
def delete_cuisine(restaurant_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can delete cuisines
    try:
        cuisine = CuisineModel.query.get_or_404(restaurant_id)
        db.session.delete(cuisine)
        db.session.commit()
        return '', 204  # No Content status code (successful deletion)
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get cuisine by name - accessible to all users
@cuisine_bp.route('/cuisines/name/<string:name>', methods=['GET'])
def get_cuisine_by_name(name):
    try:
        cuisine = CuisineModel.query.filter(CuisineModel.name.ilike(f'%{name}%')).first()  # Case-insensitive match
        if not cuisine:
            return jsonify({"message": "Cuisine not found"}), 404  # Not Found status code
        return CuisineSchema().jsonify(cuisine), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get cuisines by city - accessible to all users
@cuisine_bp.route('/cuisines/city/<string:city>', methods=['GET'])
def get_cuisines_by_city(city):
    try:
        cuisines = CuisineModel.query.filter(CuisineModel.city.ilike(f'%{city}%')).all()
        if not cuisines:
            return jsonify({"message": "No cuisines found for this city"}), 404  # Not Found status code
        return CuisineSchema(many=True).jsonify(cuisines), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error
