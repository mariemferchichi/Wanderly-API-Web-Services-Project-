from flask import request, jsonify
from flask_smorest import Blueprint
from app.models import TransportationModel
from flask_login import login_required, current_user
from app import db
from app.schemas import TransportationSchema
from sqlalchemy.exc import SQLAlchemyError

# Create the blueprint for transportation routes
transportation_bp = Blueprint('Transportation', __name__)

# Define a route to get all transportation options
@transportation_bp.route('/transportations', methods=['GET'])
def get_transportations():
    try:
        transportations = TransportationModel.query.all()
        return jsonify([{
            'transport_id': transportation.transport_id,
            'type': transportation.type,
            'details': transportation.details
        } for transportation in transportations]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500



# Define a route to add a new transportation option
@transportation_bp.route('/transportations', methods=['POST'])
def add_transportation():
    try:
        data = request.get_json()
        new_transportation = TransportationModel(
            type=data['type'],
            details=data['details']
        )
        db.session.add(new_transportation)
        db.session.commit()
        return jsonify({
            'transport_id': new_transportation.transport_id,
            'type': new_transportation.type,
            'details': new_transportation.details
        }), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Define a route to update an existing transportation option
@transportation_bp.route('/transportations/<int:id>', methods=['PUT'])
def update_transportation(id):
    try:
        data = request.get_json()
        transportation = TransportationModel.query.get(id)
        if transportation:
            transportation.type = data['type']
            transportation.details = data['details']
            db.session.commit()
            return jsonify({
                'transport_id': transportation.transport_id,
                'type': transportation.type,
                'details': transportation.details
            }), 200
        else:
            return jsonify({"message": "Transportation not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Define a route to delete a transportation option
@transportation_bp.route('/transportations/<int:id>', methods=['DELETE'])
def delete_transportation(id):
    try:
        transportation = TransportationModel.query.get(id)
        if transportation:
            db.session.delete(transportation)
            db.session.commit()
            return jsonify({"message": "Transportation deleted successfully"}), 200
        else:
            return jsonify({"message": "Transportation not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500
