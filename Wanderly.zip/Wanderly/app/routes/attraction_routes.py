from flask import request, jsonify
from flask_smorest import Blueprint
from flask_login import login_required, current_user
from app.models import AttractionModel
from app import db
from app.schemas import AttractionSchema
from sqlalchemy.exc import SQLAlchemyError

attraction_bp = Blueprint("Tourist Attractions", __name__)

# Only admin can create, update, or delete attractions
@attraction_bp.route('/attractions', methods=['POST'])
@login_required
def create_attraction():
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can create
    try:
        data = request.get_json()
        attraction = AttractionModel(**data)
        db.session.add(attraction)
        db.session.commit()
        return AttractionSchema().jsonify(attraction), 201  # Created status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

@attraction_bp.route('/attractions/<int:attraction_id>', methods=['PUT'])
@login_required
def update_attraction(attraction_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can update
    try:
        attraction = AttractionModel.query.get_or_404(attraction_id)
        data = request.get_json()
        for key, value in data.items():
            setattr(attraction, key, value)
        db.session.commit()
        return AttractionSchema().jsonify(attraction), 200  # Success status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

@attraction_bp.route('/attractions/<int:attraction_id>', methods=['DELETE'])
@login_required
def delete_attraction(attraction_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can delete
    try:
        attraction = AttractionModel.query.get_or_404(attraction_id)
        db.session.delete(attraction)
        db.session.commit()
        return '', 204  # No Content status code (successful deletion)
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get all attractions - accessible to all users
@attraction_bp.route('/attractions', methods=['GET'])
def get_attractions():
    try:
        attractions = AttractionModel.query.all()
        return AttractionSchema(many=True).jsonify(attractions), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error


# Get attraction by name - accessible to all users
@attraction_bp.route('/attractions/name/<string:name>', methods=['GET'])
def get_attraction_by_name(name):
    try:
        attraction = AttractionModel.query.filter(AttractionModel.name.ilike(f'%{name}%')).all()
        if not attraction:
            return jsonify({"message": "Attraction not found"}), 404  # Not Found status code
        return AttractionSchema(many=True).jsonify(attraction), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get attraction by city - accessible to all users
@attraction_bp.route('/attractions/city/<string:city>', methods=['GET'])
def get_attractions_by_city(city):
    try:
        attractions = AttractionModel.query.filter(AttractionModel.city.ilike(f'%{city}%')).all()
        if not attractions:
            return jsonify({"message": "No attractions found for this city"}), 404  # Not Found status code
        return AttractionSchema(many=True).jsonify(attractions), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error
