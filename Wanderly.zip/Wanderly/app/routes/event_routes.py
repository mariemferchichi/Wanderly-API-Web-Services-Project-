from flask import request, jsonify
from flask_smorest import Blueprint
from flask_login import login_required, current_user
from app.models import EventModel
from app import db
from app.schemas import EventSchema
from sqlalchemy.exc import SQLAlchemyError

event_bp = Blueprint("Events", __name__)

# Only admin can create an event
@event_bp.route('/events', methods=['POST'])
@login_required
def create_event():
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can create events
    try:
        data = request.get_json()
        event = EventModel(**data)
        db.session.add(event)
        db.session.commit()
        return EventSchema().jsonify(event), 201  # Created status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get all events - accessible to all users
@event_bp.route('/events', methods=['GET'])
def get_events():
    try:
        events = EventModel.query.all()
        return EventSchema(many=True).jsonify(events), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error


# Get event by name - accessible to all users
@event_bp.route('/events/name/<string:name>', methods=['GET'])
def get_event_by_name(name):
    try:
        event = EventModel.query.filter(EventModel.name.ilike(f'%{name}%')).first()  # Use ilike for case-insensitive match
        if not event:
            return jsonify({"message": "Event not found"}), 404  # Not Found status code
        return EventSchema().jsonify(event), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Only admin can update an event
@event_bp.route('/events/<int:event_id>', methods=['PUT'])
@login_required
def update_event(event_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can update events
    try:
        event = EventModel.query.get_or_404(event_id)
        data = request.get_json()
        for key, value in data.items():
            setattr(event, key, value)
        db.session.commit()
        return EventSchema().jsonify(event), 200  # Success status code
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Only admin can delete an event
@event_bp.route('/events/<int:event_id>', methods=['DELETE'])
@login_required
def delete_event(event_id):
    if current_user.role != 'Admin':
        return jsonify({"message": "Permission denied"}), 403  # Only admin can delete events
    try:
        event = EventModel.query.get_or_404(event_id)
        db.session.delete(event)
        db.session.commit()
        return '', 204  # No Content status code (successful deletion)
    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": str(e)}), 500  # Internal Server Error

# Get events by city - accessible to all users
@event_bp.route('/events/city/<string:city>', methods=['GET'])
def get_events_by_city(city):
    try:
        events = EventModel.query.filter(EventModel.city.ilike(f'%{city}%')).all()
        if not events:
            return jsonify({"message": "No events found for this city"}), 404  # Not Found status code
        return EventSchema(many=True).jsonify(events), 200  # OK status code
    except SQLAlchemyError as e:
        return jsonify({"message": str(e)}), 500  # Internal Server Error
